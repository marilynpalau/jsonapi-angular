# jsonapi-angular

Consumir API Rest con estructura jsonApi con angularJs
